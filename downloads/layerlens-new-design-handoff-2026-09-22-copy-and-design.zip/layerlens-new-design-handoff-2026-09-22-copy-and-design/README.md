# LayerLens new design: designer and engineering handoff

This package contains ONLY the new reference-design version updated September 22, 2026. It does not contain the old dark/light review sites or the abandoned layout adaptation.

## Authoritative version
- Review: https://jakemeany523.github.io/layerlens-website-review/redesign-copy-v2/
- Source commit: fabf1e83d109cec0bfcc13f85bb3b28b6ce7c6e2
- Source folder: redesign-copy-v2/
- Design reference: LayerLens/Website-Redesign, 2026-09-stratix-public-site/public-home.html, commit 3e0ac1ce3a1f962477f729360f5716cd1768a4c2.
- Direction: preserve the reference design; change copy and destination links only.

## Included files
- index.html: complete page, with the CSS, responsive rules, SVG graphics, animation code, and JavaScript interactions inline. This is the exact file served at the review URL, not a reconstruction.
- logos/: all 34 referenced asset files, including SVG logos, favicon, and the social image.
- IMPLEMENTATION.md: setup, design preservation, interactions, and integration boundaries.
- manifest.json: source provenance and SHA-256 hashes for every site file.

## Run locally
From this folder, run `python3 -m http.server 8080`, then open http://localhost:8080/.
No build step, package manager, framework, or API key is required.

## Deploy
Upload index.html and the entire logos/ directory together to any static host. Preserve case-sensitive asset names and relative paths. Update canonical, Open Graph URL/image, and production destination links for the chosen domain.

Inter is loaded from Google Fonts. An internet connection is needed to fetch the font; fallback system fonts remain available. The Google Fonts resource is an external dependency, not a missing file in the archive.

## Changes in this version (2026-09-22, copy + design)
- All copy changes from the copy-only version (see redesign-copy/).
- Environments, Evaluations, Synthetic Data are now co-equal: equal column widths, environment card emphasis styling removed.
