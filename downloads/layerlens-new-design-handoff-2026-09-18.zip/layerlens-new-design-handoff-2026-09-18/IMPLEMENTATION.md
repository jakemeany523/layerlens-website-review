# Implementation notes

## Design preservation
Use index.html as the visual and interaction source of truth. Its styling and HTML element sequence were checked against the referenced design. Preserve typography, spacing, breakpoints, gradients, SVG paths, motion timing, cards, section order, and the five-chapter walkthrough. Do not substitute the earlier review-dark or review-light components.

The CSS is in the head style block. Runtime JavaScript is in the final script block. Organization metadata is in a separate JSON-LD block. These may be extracted into framework components or separate files during implementation while preserving behavior.

## Copy
Hero: Agent Readiness Platform. Your business is your benchmark. The systems your agents use. The situations they need to handle. The outcomes your business requires. Evaluate. Simulate. Generate.
Core capabilities: Agent Environments, Agent Evals, Synthetic Data.
Use the exact copy in the HTML for implementation. Source-design guarantees and aggregate statistics were replaced in this version; do not restore them from the original reference.

## Existing interactions
- Mobile navigation and section navigation.
- Hero task animation and connecting lines.
- Environment selector: Salesforce, Linear, SEC EDGAR, Stripe, Gmail.
- Five-chapter walkthrough, chapter navigation, failure-case control, and illustrative results.
- Grader/judge/scorer tabs and example comparison controls.
- Role tabs, evidence messaging rotation, scroll reveals, counters, and reduced-motion handling.

These are browser-side illustrative interactions. There is no live agent execution service, persistent environment, real task run, authentication integration, or billing service in this package. Example scores and task outcomes must remain identifiable as illustrative.

## Backend work still needed
- Live public-agent execution and approved environment service endpoints.
- Signup allowance, session carryover, and authentication flow, if included in the production scope.
- Email subscription integration. The current form is explicitly a preview and does not save or submit addresses.
- Confirm production CTA, sign-in, and blog destinations. These currently link to existing external LayerLens routes.

## Launch review
This is an implementation handoff of the review site, not a claim that backend integration is complete. Review remaining product descriptions, illustrative figures, provider-logo coverage, and social image with product/design before production launch.

## Verified for this handoff
- index.html is byte-for-byte identical to the public review URL when packaged.
- All referenced local logo/image files are included.
- Original stylesheet and HTML element order preserved against the design reference.
- JavaScript syntax, unique IDs, internal anchors, desktop overflow, environment selection, and chapter transition were checked in the preceding implementation pass.
- No browser console errors were reported in that pass.

Engineering should run its normal mobile, keyboard, reduced-motion, browser, and production integration checks after porting.
